from pathlib import Path
import csv
import hashlib
import json
import re
from collections import Counter, defaultdict, deque

ROOT = Path(__file__).resolve().parents[2]
AUDIT = ROOT / 'Library/AssetCleanupAudit'
REPORT = ROOT / 'Reports/AssetCleanup-2026-09-25'
TARGETS = ('Assets/Thirdparty/', 'Assets/BoldPixels/')
CODE = {'.cs', '.js', '.boo', '.dll', '.pdb', '.asmdef', '.asmref', '.rsp',
        '.hlsl', '.cginc', '.shader', '.compute', '.shadergraph', '.shadersubgraph',
        '.uxml', '.uss', '.so', '.a', '.dylib', '.bundle', '.aar', '.jar', '.cpp', '.h'}
TEXT = CODE | {'.asset', '.prefab', '.unity', '.mat', '.anim', '.controller',
               '.overridecontroller', '.meta', '.json', '.txt', '.xml', '.yaml',
               '.yml', '.inputactions', '.rendertexture', '.playable', '.mask',
               '.spriteatlas', '.lighting', '.md', '.csv', '.uss', '.uxml'}
GUID = re.compile(rb'(?<![0-9a-fA-F])[0-9a-fA-F]{32}(?![0-9a-fA-F])')

def sha(p):
    with p.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

def write_json(name, value):
    (REPORT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')

def main():
    REPORT.mkdir(parents=True, exist_ok=True)
    files = {p.relative_to(ROOT).as_posix(): p for p in (ROOT / 'Assets').rglob('*') if p.is_file()}
    assets = {p: f for p, f in files.items() if not p.endswith('.meta')}
    graph = defaultdict(set)
    unity_graph = {}
    for line in (AUDIT / 'unity-dependencies.tsv').read_text(encoding='utf-8-sig').splitlines():
        parts = line.split('\t')
        unity_graph[parts[0]] = parts[1:]
        graph[parts[0]].update(parts[1:])
    missing_from_unity = sorted(set(assets) - set(unity_graph))
    if missing_from_unity:
        raise RuntimeError('Unity export is incomplete or unimported files exist: ' + repr(missing_from_unity[:20]))
    guid_paths = {}
    for line in (AUDIT / 'unity-guids.tsv').read_text(encoding='utf-8-sig').splitlines():
        path, guid = line.split('\t')
        if guid:
            guid_paths[guid.lower()] = path
    # Meta-only importer references and GUID strings in Addressables/localization
    # are not always included by AssetDatabase.GetDependencies.
    raw_refs = {}
    for path, f in files.items():
        if f.suffix.lower() not in TEXT:
            continue
        data = f.read_bytes()
        if b'\x00' in data[:128]:
            continue
        owner = path[:-5] if path.endswith('.meta') else path
        refs = set(m.group().decode('ascii').lower() for m in GUID.finditer(data))
        raw_refs[path] = sorted(refs)
        graph[owner].update(guid_paths[g] for g in refs if g in guid_paths)
    roots = defaultdict(list)
    for path, f in assets.items():
        if not path.startswith(TARGETS):
            roots[path].append('Outside downloaded-content cleanup scope; all Assets/Game preserved')
        if f.suffix.lower() in CODE:
            roots[path].append('Protected code, shader source, editor UI or compiled library')
        if any('/' + name + '/' in path for name in ('Resources', 'StreamingAssets', 'Editor Default Resources', 'Gizmos')):
            roots[path].append('Implicit runtime/editor loading directory')
        if re.search(r'(?i)(license|licence|copyright|notice|ofl)', f.name):
            roots[path].append('License/attribution')
        meta = files.get(path + '.meta')
        if meta and re.search(r'(?m)^[ \t]*assetBundleName:[ \t]*[^\s]', meta.read_text(encoding='utf-8-sig')):
            roots[path].append('Named AssetBundle entry')
    for path in (AUDIT / 'unity-roots.txt').read_text(encoding='utf-8-sig').splitlines():
        roots[path].append('Build/open scene, preloaded asset, Addressables entry or discovered editor config')
    for setting in (ROOT / 'ProjectSettings').rglob('*'):
        if setting.is_file():
            for m in GUID.finditer(setting.read_bytes()):
                p = guid_paths.get(m.group().decode().lower())
                if p:
                    roots[p].append('ProjectSettings GUID reference: ' + setting.name)
    # All project code is retained. Resolve literal full asset paths and constant
    # base + relative asset paths, including assets used only by editor utilities.
    literal_hits = {}
    for path, f in assets.items():
        if f.suffix.lower() not in CODE:
            continue
        data = f.read_text(encoding='utf-8-sig', errors='replace')
        literals = re.findall(r'"([^"\r\n]+)"', data)
        bases = [x for x in literals if x.startswith('Assets/') and x.endswith('/')]
        hits = set(x for x in literals if x in assets)
        for base in bases:
            hits.update(base + x for x in literals if base + x in assets)
        # Include resource-relative literals and filename literals without
        # treating a directory prefix as a request to preserve the entire pack.
        for literal in literals:
            if len(literal) < 5 or literal.endswith('/'):
                continue
            if Path(literal).suffix.lower() in TEXT | {'.png', '.jpg', '.ttf', '.otf', '.fbx', '.wav', '.mp3'}:
                hits.update(p for p in assets if p.endswith('/' + literal))
        if hits:
            literal_hits[path] = sorted(hits)
            for p in hits:
                roots[p].append('Code path: ' + path)
    base = 'Assets/Thirdparty/Layer Lab/GUI Pro-SurvivalClean/ResourcesData/'
    menu_paths = ['Fonts/Oxanium-Bold SDF.asset',
                  'Sprites/Components/Popup/Popup_Frame01_White1.png',
                  'Sprites/Components/Button_Custom/Btn_TextButton_Square01_White1.png',
                  'Sprites/Demo/Demo_LanguageFlag/Icon_LanguageFlag_Small01_Eng.png',
                  'Sprites/Demo/Demo_LanguageFlag/Icon_LanguageFlag_Small01_Jpn.png']
    for p in menu_paths:
        assert base + p in assets, p
        roots[base + p].append('MenuSceneSetup evaluated constant/concatenated asset path')
    # A GUID can identify an addressable folder rather than a single file.
    folders = {p for p in guid_paths.values() if p.startswith('Assets/') and (ROOT / p).is_dir()}
    for folder in folders:
        graph[folder].update(p for p in assets if p.startswith(folder + '/'))
    parents = {p: None for p in roots}
    queue = deque(roots)
    while queue:
        p = queue.popleft()
        for dep in sorted(graph[p]):
            if dep not in parents:
                parents[dep] = p
                queue.append(dep)
    kept = set(assets) & set(parents)
    candidates = sorted(set(assets) - kept)
    assert all(p.startswith(TARGETS) and Path(p).suffix.lower() not in CODE for p in candidates)
    assert not [(p,d) for p in kept for d in graph[p] if d in candidates]
    deletion_rows = []
    for p in candidates:
        for actual in [p, p + '.meta']:
            if actual in files:
                deletion_rows.append({'path': actual, 'bytes': files[actual].stat().st_size, 'sha256': sha(files[actual])})
    with (REPORT / 'deletion-manifest.csv').open('w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, fieldnames=['path', 'bytes', 'sha256'])
        w.writeheader()
        w.writerows(deletion_rows)
    deleted_paths = {r['path'] for r in deletion_rows}
    protected = {p: sha(f) for p, f in files.items() if p not in deleted_paths}
    write_json('protected-file-hashes.json', protected)
    write_json('retention-reasons.json', {'roots': roots, 'reached_from': parents, 'code_literal_hits': literal_hits})
    write_json('baseline-guid-references.json', raw_refs)
    write_json('baseline-guid-paths.json', guid_paths)
    write_json('baseline-unity-dependencies.json', unity_graph)
    groups = defaultdict(lambda: {'assets': 0, 'bytes_including_meta': 0})
    ext_groups = Counter()
    for p in candidates:
        group = '/'.join(p.split('/')[:4]) if p.startswith('Assets/Thirdparty/Models/') else '/'.join(p.split('/')[:3])
        groups[group]['assets'] += 1
        groups[group]['bytes_including_meta'] += files[p].stat().st_size + (files[p+'.meta'].stat().st_size if p+'.meta' in files else 0)
        ext_groups[Path(p).suffix.lower()] += 1
    summary = {'assets_before': len(assets), 'asset_files_and_meta_before': len(files),
               'bytes_before': sum(f.stat().st_size for f in files.values()),
               'delete_assets': len(candidates), 'delete_files_including_meta': len(deletion_rows),
               'delete_bytes_including_meta': sum(r['bytes'] for r in deletion_rows),
               'keep_assets': len(kept), 'protected_code_assets': sum(f.suffix.lower() in CODE for f in assets.values()),
               'root_count': len(roots), 'groups': groups, 'extensions': ext_groups,
               'removed_demo_scenes': [p for p in candidates if p.endswith('.unity')],
               'retained_thirdparty_assets': sum(p.startswith('Assets/Thirdparty/') for p in kept)}
    write_json('summary-before.json', summary)
    (AUDIT / 'kept-assets.txt').write_text('\n'.join(sorted(kept)), encoding='utf-8')
    (AUDIT / 'candidate-assets.txt').write_text('\n'.join(candidates), encoding='utf-8')
    print(json.dumps(summary, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
