from pathlib import Path
import csv
import hashlib
import json
import re
from collections import Counter

root = Path(__file__).resolve().parents[2]
report = root / 'Reports/AssetCleanup-2026-09-25'
audit = root / 'Library/AssetCleanupAudit'
def read(name):
    return json.loads((report / name).read_text(encoding='utf-8-sig'))
def csv_read(name):
    return list(csv.DictReader((report / name).open(encoding='utf-8-sig')))
deleted = csv_read('deletion-manifest.csv')
folders = csv_read('removed-folder-metadata.csv')
removed = {r['path'] for r in deleted + folders}
hashes = read('protected-file-hashes.json')
missing = []
changed = []
for path, expected in hashes.items():
    if path in removed:
        continue
    f = root / path
    if not f.is_file():
        missing.append(path)
        continue
    with f.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    if digest != expected:
        changed.append(path)
remaining_deleted = sorted(p for p in removed if (root / p).exists())
guids = read('baseline-guid-paths.json')
removed_guids = {g: p for g, p in guids.items() if p in removed or p + '.meta' in removed}
guid_pattern = re.compile(rb'(?<![0-9a-fA-F])[0-9a-fA-F]{32}(?![0-9a-fA-F])')
references_to_deleted = []
baseline_refs = read('baseline-guid-references.json')
for path in baseline_refs:
    if path in removed or not (root / path).is_file():
        continue
    for match in guid_pattern.finditer((root / path).read_bytes()):
        guid = match.group().decode().lower()
        if guid in removed_guids:
            references_to_deleted.append([path, removed_guids[guid]])
dependency_changes = []
before_deps = read('baseline-unity-dependencies.json')
after_deps = {}
for line in (audit / 'after-unity-dependencies.tsv').read_text(encoding='utf-8-sig').splitlines():
    parts = line.split('\t')
    after_deps[parts[0]] = set(filter(None, parts[1:]))
for path in (audit / 'kept-assets.txt').read_text(encoding='utf-8-sig').splitlines():
    expected = set(filter(None, before_deps[path]))
    actual = after_deps.get(path)
    if actual != expected:
        dependency_changes.append({'path': path, 'before': sorted(expected), 'after': sorted(actual) if actual is not None else None})
def issues(stage, kind):
    return sorted((audit / f'{stage}-{kind}-issues.tsv').read_text(encoding='utf-8-sig').splitlines())
new_scene_issues = sorted(set(issues('after','scene')) - set(issues('baseline','scene')))
new_prefab_issues = sorted(set(issues('after','prefab')) - set(issues('baseline','prefab')))
files = [p for p in (root/'Assets').rglob('*') if p.is_file()]
before = read('summary-before.json')
verification = {
    'missing_preserved_files': missing, 'modified_preserved_files': changed,
    'deleted_paths_still_present': remaining_deleted,
    'remaining_references_to_deleted_guids': references_to_deleted,
    'changed_unity_dependencies': dependency_changes,
    'new_scene_issues': new_scene_issues, 'new_prefab_issues': new_prefab_issues,
    'preexisting_scene_issues': issues('baseline','scene'),
    'preexisting_prefab_issues': issues('baseline','prefab'),
    'preserved_files_verified_by_sha256': len(hashes)-len(folders),
    'preserved_game_files_verified_by_sha256': sum(p.startswith('Assets/Game/') for p in hashes),
    'assets_after': sum(p.suffix != '.meta' for p in files),
    'asset_files_and_meta_after': len(files),
    'bytes_after': sum(p.stat().st_size for p in files),
    'bytes_freed': sum(int(r['bytes']) for r in deleted+folders),
    'deleted_assets': before['delete_assets'], 'deleted_asset_and_meta_files': len(deleted),
    'removed_empty_directories': len(folders), 'unity_dependency_sets_verified': len(after_deps)
}
verification['passed'] = not any([missing, changed, remaining_deleted, references_to_deleted, dependency_changes, new_scene_issues, new_prefab_issues])
(report / 'verification.json').write_text(json.dumps(verification, ensure_ascii=False, indent=2),encoding='utf-8')
print(json.dumps(verification, ensure_ascii=False, indent=2))
assert verification['passed'], 'Verification failed; inspect report before declaring cleanup complete.'
